export default function isNullObject(object) {

    if(object === null || object === undefined)
        return true;
    if(JSON.stringify(object) === '{}')
        return true;
    return false;
}
