import ksdtContractInfo from '../lib/msdtContract';
import khcContractInfo from "../lib/khcContract";

let KHCExtension = window.KHCExtension;
let Contract = null;

const khcContractAddress = process.env.REACT_APP_KHC_ADDRESS;
const ksdtContractAddress = process.env.REACT_APP_USDT_ADDRESS;
const vdsContractAddress = process.env.REACT_APP_VDS_ADDRESS;
const proContractAddress = process.env.REACT_APP_PRO_ADDRESS;

const interval = setInterval(async () => {
    KHCExtension = window.KHCExtension;
    if (!KHCExtension) return;
    if (KHCExtension) {
        ksdtContractInfo.contract_address = KHCExtension.address.toHex(ksdtContractAddress);
        // contractInfo.contract_address = KHCExtension.address.toHex(contractAddress);
        // purchaseContractInfo.contract_address = KHCExtension.address.toHex(purchaseContract);
        // depositContractInfo.contract_address = KHCExtension.address.toHex(depositContract);
        // rewardContractInfo.contract_address = KHCExtension.address.toHex(rewardContract);
        // exchangeContractInfo.contract_address = KHCExtension.address.toHex(exchangeContract);
        khcContractInfo.contract_address = KHCExtension.address.toHex(khcContractAddress);

        clearInterval(interval);
        // await getContract();
    }
}, 1000);


export function getAddress() {
    if (KHCExtension && KHCExtension.defaultAddress) {
        return KHCExtension.defaultAddress.base58
    } else {
        return ''
    }
}

// const getContract = async () => {
//     if (Contract) return;
//     try {
//         // Contract = await KHCExtension.contract().at(contractAddress)
//         Contract = await KHCExtension.contract(contractInfo.abi.entrys, contractInfo.contract_address);
//     } catch (err) {
//         await getContract()
//     }
// };

// const get20Contract = async (contractAddress) => {
//     if (Contract) return;
//     try {
//         // Contract = await KHCExtension.contract().at(contractAddress)
//         Contract = await KHCExtension.contract(msdtContractInfo.abi.entrys, contractAddress);
//     } catch (err) {
//         await getContract()
//     }
// };

export function checkAddress() {
    if (!KHCExtension) {
        return { success: false, message: '请先安装 KHCExtension 插件' }
    } else if (!KHCExtension.defaultAddress) {
        return { success: false, message: '请先创建钱包或者解锁插件' }
    } else {
        return { success: true, address: KHCExtension.defaultAddress.base58 }
    }
}

export async function signTimestamp() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    const params = {
        timestamp:timestamp,
        address: KHCExtension.defaultAddress.base58,
        // signature:timestamp
    };

    try {
        params.sign = await KHCExtension.khc.sign(signature);

        return params;

    } catch (e) {
        console.warn(e);
        return false;
    }
}

export function signSimulate() {
    const timestamp = parseInt(new Date().getTime() / 1000, 10);
    const signature = `0x${timestamp.toString(16)}`;
    return {
        timestamp: timestamp,
        address: KHCExtension.defaultAddress.base58,
        sign: signature
    };
}

export async function getBalance() {
    const result = await KHCExtension.khc.getUnconfirmedAccount(KHCExtension.defaultAddress.base58);
    let balance = Number(KHCExtension.fromKoho(result.balance));
    balance = (Math.floor(balance * 10000) / 10000).toFixed(4)
    return Number(balance)
}


export async function get20BalanceResult() {
    let result = await KHCExtension.contract(ksdtContractInfo.abi.entrys, ksdtContractInfo.contract_address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();
    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromKoho(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)
    return balance_20
}

export async function getUSDTBalance(){
    return await getM20BalanceResult(ksdtContractAddress);
}

export async function getVDSBalance(){
    return await getM20BalanceResult(vdsContractAddress);
}

export async function getProBalance(){
    return await getM20BalanceResult(proContractAddress);
}

export async function getM20BalanceResult(address) {

    let result = await KHCExtension.contract(ksdtContractInfo.abi.entrys, address);
    const res = await result.balanceOf(KHCExtension.defaultAddress.base58).call();

    let temp_20 = window.KHCExtension.toDecimal(res);
    let balance_20 = (Math.floor(Number(window.KHCExtension.fromKoho(temp_20)) * 10000) / 10000).toFixed(4);
    balance_20 = Number(balance_20)

    return balance_20
}

export async function getRegisterFee(){

    let result = await window.KHCExtension.contract(khcContractInfo.abi.entrys, khcContractInfo.contract_address);

    try {
        let fee = await result.campaignFee().call();
        fee = KHCExtension.toDecimal(fee);
        return KHCExtension.fromKoho(fee);
    } catch (e) {

        console.log('result', e);

        return false;
    }
}

// -------- KHC 激活地址 ----------
export async function KHCCampaignNode(address, kid, invitationCode, fee) {

    let result = await window.KHCExtension.contract(khcContractInfo.abi.entrys, khcContractInfo.contract_address);

    try {
        return await result.campaignNode(address || getAddress(), kid.toString(), invitationCode.toString()).send({ callValue: KHCExtension.toKoho(fee || 0) });
    } catch (e) {
        console.warn(e);

        return false;
    }
}



