export default function kidHidden(kid) {
    if(!kid || kid === "")
        return "";

    let k1 = kid.substr(0,2);
    let k2 = kid.substr(kid.length - 1, 2);

    return k1 + "****" + k2;
}
