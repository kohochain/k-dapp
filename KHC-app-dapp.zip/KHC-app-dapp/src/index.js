import React from 'react';
import ReactDOM from 'react-dom';
import './app.less';
import App from './pages/App';
import { Provider } from 'react-redux';
import store from './store';
import * as serviceWorker from './serviceWorker';
import initNECaptchaWithFallback from './initCaptchaWithFallback';

Storage.signToken = '';

const captchaInstance = {};

Storage.CodeVervify = function () {
    return new Promise(function (resolve, reject) {
        captchaInstance.onVerify = function (err, data) {
            console.log(err, data)
            if (!err) resolve({
                ...data,
                message: 'success'
            });
        }
        captchaInstance.onClose = function () {
            resolve({
                message: 'close'
            });
        }
        if (captchaInstance.instance) {
            captchaInstance.instance.refresh()
            captchaInstance.instance.popUp()
        } else {
            initNECaptchaWithFallback(window)({
                captchaId: 'e069698737904f288d33712555553d62',
                element: '#captcha',
                mode: 'popup',
                width: '320px',
                lang: 'zh-CN',
                onVerify: function (err, data) {
                    captchaInstance.onVerify(err, data)
                },
                onClose: function () {
                    captchaInstance.onClose()
                }
            }, function (instance) {
                captchaInstance.instance = instance
                captchaInstance.instance.popUp();
            }, function (err) {
                reject(err);
            })
        }
    })
}

Storage.mobile = window.innerWidth <= 900;

function resize() {

    if((window.innerWidth <= 900) !== Storage.mobile)
    {
        window.location.reload();
    }
}

resize();

window.onresize = () => {
    // console.log('1111')
    resize();
}

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
