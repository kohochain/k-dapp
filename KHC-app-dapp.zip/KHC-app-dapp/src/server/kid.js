import {get, post} from "./method";

const pre = '/reward';

export default {
    //查看kid邀请列表
    inviteRewardPipeline: data => post(`${pre}/invitePipeline`, data),

    //查询用户信息
    postRewardAddressInfo: (data) => post(`${pre}/addressInfo`, data),

    //查询邀请用户列表
    postRewardInviteList: (data) => post(`${pre}/inviteList`, data),

    /**
     * 查询KID是否存在
     *
     */
    getRewardCheckKID: (data) => get(`${pre}/checkKid`, data),

    /**
     * 接受邀请
     *
     */
    postRewardAcceptInvite: (data) => post(`${pre}/acceptInvite`, data),

    /**
     * 领取手续费
     */
    getKHTRewardFee: data => post(`${pre}/getRewardFee`, data),

    /**
     * 查询是否可以领奖
     */
    getKHTRewardAirdrop: data => get(`${pre}/airdrop`, data),

    /**
     * 领奖Pro空投
     */
    getKHTProAirdrop: data => post(`${pre}/getAirdrop`, data),
}
