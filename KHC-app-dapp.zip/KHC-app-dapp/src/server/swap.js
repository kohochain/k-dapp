import { get, post } from './method';

const request = {
    /**
     * 获取资金池列表
     *
     */
    getApiPoolList: (data) => get(`/api/pool/list`, data),

    /**
     * 平台支持的所有币种列表
     *
     */
    getApiTokenList: (data) => get(`/api/token/list`, data),

    /**
     * 获取兑换记录
     *
     */
    getApiSwapRecords: (data) => get(`/api/swap/records`, data),

    /**
     * 获取份额记录
     *
     */
    getApiFundRecords: (data) => get(`/api/fund/records`, data),


    /**
     * 获取分红记录
     *
     */
    getApiBonusRecords: (data) => get(`/api/bonus/records`, data),

    /**
     * 交易对统计数据
     *
     */
    getApiStatistics: (data) => get(`/api/statistics`, data),

    /**
     * 平台统计数据
     *
     */
    getApiStatisticsPlatform: (data) => get(`/api/statistics/platform`, data),


    /**
     * 登录
     *
     */
    postAuthLogin: (data) => post(`/auth/login`, data),


    /**
     * 账户信息
     *
     */
    getApiAccount: (data) => get(`/api/account`, data),

    /**
     * 获取预兑换数量
     *
     */
    postApiSwapPre: (data) => post(`/api/swap/pre`, data),

    /**
     * 获取20余额
     *
     */
    getRC20Balance: (data) => get(`/node/api/access/rc20_balances`, data),
};

export default request;
