import { get, post } from './method';

export default {
    // 当期拼团信息
    getPtInfo: data => get(`/pt/info`, data),

    //当前免费次数查询
    getPtFreeInfo: data => get('/pt/free/info', data),

    // 当期房间拼团信息
    getPtRoomInfo: data => get(`/pt/room/info`, data),

    // 开启关闭自动拼团
    postSetAuto: data => post(`/pt/auto`, data),

    // 免费拼团次数，是否拼团
    getPtBalance: (data) => get(`/pt/balance`, data),

    // 平台拼团流水
    getPtPipelines: (data) => get(`/pt/pipelines/platform`, data),

    // 我的拼团流水
    getPtPipelinesMy: (data) => get('/pt/pipeline', data),

    // 我的余额流水
    getMyUSDTPipeline: (data) => get('/my/usdt/pipeline', data),

    // 我的积分流水
    getMyScorePipeline: (data) => get('/my/score/pipeline', data),

    // 我的奖励明细
    getMyRewardPipeline: (data) => get('/my/reward/pipeline', data),

    //排行榜
    getPtBoard: (data) => get('/pt/board', data),

    //春节排行榜
    getPtActivity: (data) => get('/pt/newYear/activity', data),

    //日期list
    getPtDateList: (data) => get('/pt/board/date/list', data),

    //公告信息
    getPtNoticeInfo: (data) => get('/pt/notice/info', data),

    //我的信息
    getPtGroupInfo:(data) => get('/pt/groupInfo', data),

    //分红奖励记录
    getPtReward:(data) => get('/pt/pt/reward', data),

    //邀请列表
    getPtInviteList:(data) => get('/pt/inviteList', data),

    //邀请奖励流水
    getPtRewardList:(data) => get('/pt/rewardList', data),

    //最近三个幸运儿
    getLuckMan: (data) => get('/pt/pt/luck/man', data),

    //参与拼团
    postPtJoin: (data) => post('/pt', data),

    //当前轮次用户拼团信息
    getPtAddressInfo: (data) => get('/pt/pt/info/address', data),

    //矿机信息
    getMachineInfo: (data) => get('/machine/info', data),

    //矿机流水
    getMachinePipeline: (data) => get('/machine/mint/pipeline/date', data),

    //我的矿机
    getMachineMy: (data) => get('/machine/my', data),

    //系统配置
    getSystemInfo: (data) => get('/pt/pt/system/info', data),
}
