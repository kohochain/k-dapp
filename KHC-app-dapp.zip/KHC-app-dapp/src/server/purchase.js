import { get, post} from './method';

const request = {
    //---------------------------------------Purchase Controller---------------------------------------


    /**
     * 共振进度
     *
     */
    getPurchaseAddressInfo: (data) => get(`/purchaseLOT/purchaseInfo`, data),

    /**
     * 共振余额
     *
     */
    postPurchaseBalance: (data) => post(`/purchaseLOT/purchaseBalance`, data),

    /**
     * 共振
     *
     */
    postPurchase: (data) => post(`/purchaseLOT/purchase`, data),

    /**
     * 共振记录
     *
     */
    postPurchaseHistory: (data) => post(`/purchaseLOT/purchaseHistory`, data),

    /**
     * 计算共振数量
     *
     */
    getPurchaseQuantity: (data) => get(`/purchaseLOT/purchaseQuantity`, data),

    /**
     * 共振结果
     *
     */
    getPurchaseResult: (data) => get(`/purchaseLOT/purchaseResult`, data),

    //postPurchaseBalance
}

export default request;
