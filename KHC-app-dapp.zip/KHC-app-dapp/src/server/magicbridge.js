import { get, post } from './method';

const pre = '/exchange';

export default {
    // asset配置
    exchangeConfig: (data) => get(`${pre}/access/config`, data),

    // 查询地址提币限额
    exchangeLimit: (data) => get(`${pre}/access/limit`, data),

    // 查询地址提币限额
    exchangeAddress: (data) => post(`${pre}/address`, data),
}
