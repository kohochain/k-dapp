import React, {Component} from "react";
import {HashRouter as Router, Route} from 'react-router-dom';
import {LanguageContext} from './languageContext';
import setLanguage from './setLanguage';
import {TabBar, Toast} from 'antd-mobile';

import {getAddress, signTimestamp} from '../utils/mdc';
import connect from '../store/connect';
import net from "../server";
import Kid from './KID';
import InviteKid from "./KID/InviteKid";
import Reward from "./KID/Reward";
import Empty from "./KID/Empty";
import Home from "./Home";
import Web from "./KID/Web";
import WebHome from "./WebHome";
import Guide from "./Guide";

class App extends Component {
	constructor(props) {
		super(props);

		this.state = {
			init: false,
			language: 'en',
		};

		this.setLanguage = this.setLanguage.bind(this);
		this.login = this.login.bind(this);
	}

	componentDidMount() {
		this.freshBalance().then();
		this.loadLocales();

		// setTimeout(()=>{
		// 	this.login();
		// }, 1000);
	}

	async login() {
		const {address} = this.props.redux;

		if (address) {

			localStorage.setItem('address', address);

			const params = await signTimestamp();

			if(!params){
				setTimeout(() => this.login(), 1000);
				return;
			}

			net.authPostLogin(params).then(res => {
				if(res.response_code === '00')
				{

				}
				else {
					Toast.fail(res.response_msg);
				}
			});

		} else {
			setTimeout(() => this.login(), 10000)
		}
	}

	setLanguage(currentLocale) {
		localStorage.setItem('lang', currentLocale);
		setLanguage(currentLocale).then(() => {
			this.setState({init: true, language: currentLocale});
		});
	}

	loadLocales() {
		let currentLocale = localStorage.getItem('lang') || 'en';
		const {href} = window.location;
		if (href.indexOf('?') > -1) {
			const params = href.split('?')[1].split('#')[0];

			const paramList = params.split('&');

			paramList.forEach((item) => {
				const [key, value] = item.split('=');
				if (key === 'lang') {
					currentLocale = value;
				}
			});
		}
		if (['zh', 'en', 'jp', 'ko'].indexOf(currentLocale) === -1) currentLocale = 'en';
		this.setLanguage(currentLocale);
	}

	setDevice() {
		const that = this;
		document.addEventListener("message", function handler(e) {
			console.log(e)
			if (e && e.data) {
				let obj = JSON.parse(e.data);
				console.log(obj.deviceId);
				that.props.setDevice(obj.deviceId);
			}
		})
	}

	async freshBalance() {
		if (getAddress() && getAddress() !== '') {

			this.props.setAddress(getAddress());

			try {
				await this.props.updateBalance();

				setTimeout(() => {
					if (this.props.redux.address !== getAddress()) {
						window.location.reload();
					}
					this.freshBalance();
				}, 30000);

			} catch (e) {
				setTimeout(() => this.freshBalance(), 3000);
			}

		} else {
			setTimeout(() => this.freshBalance(), 1000)
		}
	}

	render() {

		return (
			<LanguageContext.Provider
				value={{
					language: this.state.language,
					setLanguage: this.setLanguage,
				}}
			>
				<div className="full">
					<Router>
						<Route exact path="/" component={Kid}/>
						<Route exact path="/invite" component={InviteKid}/>
						<Route exact path="/reward" component={Reward}/>
						<Route exact path="/empty" component={Empty}/>
						<Route exact path="/dapps" component={Home}/>
						<Route exact path="/web" component={Web}/>
						<Route exact path="/dapps-web" component={WebHome}/>
						<Route exact path="/guide" component={Guide}/>
					</Router>
				</div>
			</LanguageContext.Provider>
		)
	}
}

export default connect(App);
