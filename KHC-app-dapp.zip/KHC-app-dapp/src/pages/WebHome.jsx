import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import connect from "../store/connect";
import setLanguage from "./setLanguage";
import intl from "react-intl-universal";

const Item = Popover.Item;

const imgs = {
    'down':require('../images/home/arrow-down.png'),
    'banner':require('../images/home/banner-web2.png'),
    'kdex':require('../images/home/kdex-web.png'),
    'ktmining':require('../images/home/ktmining.png'),
    'bridge':require('../images/home/bridge-web.png'),
    'swap':require('../images/home/ProSwap.png'),
    'gas':require('../images/home/gas-web.png'),
    'kid':require('../images/home/kid.png'),
};

class WebHome extends Component {

    constructor(props){
        super(props);
        this.state = {
            lang: localStorage.getItem('lang'),
        }
    }

    componentDidMount() {

    }

    componentWillUnmount() {

    }

    changeLanguage(lang) {
        setLanguage(lang).then(() => {
            this.setState({ lang })
            localStorage.setItem('lang', lang);
        })
    }

    renderCell(item, index){

        return (
            <div className={'flex-display'}>
                {index > 0 ? <div className={'home-web-card-cell-line'} /> : null}
                <div key={index} className={'home-web-card-cell'}>
                    <div className={'flex-display-col'} style={{padding:'40px 0', height:'100%'}}>
                        <img src={item.img} alt='' className={'home-web-card-cell-icon'} />
                        <div>
                            <div className={'home-web-card-cell-p1'}>{item.title}</div>
                            <div className={'home-web-card-cell-p2'}>{item.text}</div>
                        </div>
                        <div onClick={()=>{window.location = item.url}} className={'home-web-card-cell-btn flex-center'}>
                            <div className={'home-web-card-cell-p3'}>GET</div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    render() {

        const {list, step, lang} = this.state;

        let language;
        switch (lang) {
            case 'zh':
                language = '简体中文';
                break;
            case 'en':
                language = 'English';
                break;
            case 'jp':
                language = '日本語';
                break;
            case 'ko':
                language = '한국어';
                break;
            default:
                language = '简体中文';
                break;
        }

        const array = [
            {title:'KoHo Bridge', img:imgs['bridge'], text:intl.get('TEXT_51'), url:'https://bridge.khchain.io/#/'},
            {title:'Gas Station', img:imgs['gas'], text:intl.get('TEXT_52'), url:'https://gas.khchain.io/#/'},
            {title:'KDex', img:imgs['kdex'], text:intl.get('TEXT_53'), url:'https://kex.khchain.io/'},
            // {title:'ProSwap', img:imgs['swap'], text:intl.get('TEXT_54'), url:''},
            // {title:'KT Mining', img:imgs['ktmining'], text:intl.get('TEXT_55'), url:'https://kt.khchain.io/#/'},
            // {title:'KID', img:imgs['kid'], text:intl.get('TEXT_56'), url:'https://kid.khchain.io/#/'},
        ];

        return (
            <div className={'home-web'}>
                <div className={'flex-display-col'} style={{padding:'80px 270px'}}>
                    <div className={'flex-end'} style={{width:'100%', marginTop:'-40px', marginBottom:'40px'}}>
                        <Popover mask
                                 overlayClassName="fortest"
                                 overlayStyle={{ color: 'currentColor' }}
                                 visible={this.state.visible2}
                                 overlay={[
                                     (<Item key="1" value={'zh'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>简体中文</p>
                                         </div>
                                     </Item>),
                                     (<Item key="2" value={'en'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>English</p>
                                         </div>
                                     </Item>),
                                     (<Item key="3" value={'ko'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>한국어</p>
                                         </div>
                                     </Item>),
                                     (<Item key="4" value={'jp'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>日本語</p>
                                         </div>
                                     </Item>),
                                 ]}
                                 align={{
                                     overflow: { adjustY: 0, adjustX: 0 },
                                     offset: [-10, 0],
                                 }}
                            onVisibleChange={()=>{this.setState({visible2:false})}}
                                 onSelect={(opt)=>{
                                     this.setState({
                                         visible2: false,
                                     }, ()=>{
                                         this.changeLanguage(opt.props.value);
                                     });
                                 }}
                        >
                            <div className={'flex-end'}>
                                <div onClick={()=>{this.setState({visible2:true})}} className={'home-web-language'} style={{margin:0}}>
                                    <div className={'flex-between'} style={{padding:'3px 11px'}}>
                                        <div className={'home-web-language-text'}>{language}</div>
                                        <img className={'home-web-language-arrow'} alt='' src={imgs['down']} />
                                    </div>
                                </div>
                            </div>
                        </Popover>
                    </div>
                    <div className={'flex-display'}>
                        <div className={'flex-display'}>
                            <div className={'home-web-tag'}/>
                            <div className={'home-web-title'}>{intl.get('TEXT_57')}</div>
                            <div className={'home-web-tag'}/>
                        </div>
                    </div>
                    <div onClick={()=>{window.location = 'https://kex.khchain.io/'}} className={'home-web-card'}>
                        <img alt='' src={imgs['banner']} className={'home-web-card-banner'} />
                        <div style={{padding:'14px 24px'}}>
                            <div className={'home-web-card-text'}>
                                {intl.get('TEXT_64')}
                            </div>
                        </div>
                    </div>
                    <div className={'flex-display'} style={{marginTop:'32px'}}>
                        <div className={'home-web-tag'}/>
                        <div className={'home-web-title'}>{intl.get('TEXT_59')}</div>
                        <div className={'home-web-tag'}/>
                    </div>
                    <div className={'home-web-card flex-between'}>
                        {array.map((item, index)=> {
                            return this.renderCell(item, index);
                        })}
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(WebHome);
