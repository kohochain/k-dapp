import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel} from 'antd-mobile';
import intl from "react-intl-universal";
import net from "../../server";
import connect from "../../store/connect";
import moment from "moment";
import isNullObject from "../../utils/isNull";
import {getRegisterFee, signSimulate, KHCCampaignNode} from "../../utils/mdc";
import {Input} from "../Swap/components";
import BigNumber from "bignumber.js";


const imgs = {
    'avatar':require('../../images/kid/avatar.png'),
    'copy':require('../../images/kid/copy.png'),
};

class InviteKid extends Component {

    constructor(props){
        super(props);
        this.state = {
            kid:"",
            kidError:"",
            inviteKid:"",
            inviteKidError:"",
            address:'',
            addressError:'',
            balance:0,
            fee:0,
            step:0,
        }
    }

    componentDidMount() {

        if(this.props.location.query) {
            let { step, kid, id} = this.props.location.query;
            this.setState({step:step, inviteKid:kid || '', id:id || ''});
        }

        this.login();
    }

    async login(){

        let {address} = this.props.redux;

        if(address){
            this.getFee();
        }
        else {
            setTimeout(()=>{
                this.login();
            }, 1000);
        }
    }

    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    getAddress(){

        let {address} = this.props.redux;
        if(!address)
        {
            address = localStorage.getItem('address');
        }

        return address;
    }

    async getFee() {

        const fee = await getRegisterFee();

        if(fee === false)
        {
            setTimeout(()=>{this.getFee()}, 1000);
        }
        else {
            this.setState({fee:fee})
        }
    }

    getRows(){

        const {step, inviteKid, fee} = this.state;

        switch (step) {
            case 0:
                return [intl.get('TEXT_12'), intl.get('TEXT_13'), intl.get('TEXT_14', {fee:fee}),
                    intl.get('TEXT_15'), intl.get('TEXT_16'), intl.get('TEXT_17')];
            case 1:
                return [intl.get('TEXT_12'), intl.get('TEXT_18'), intl.get('TEXT_19', {fee:fee}), intl.get('TEXT_20')];
            case 2:
                return [intl.get('TEXT_12'), intl.get('TEXT_18'), intl.get('TEXT_21'), intl.get('TEXT_22')];
        }
    }

    check(){

        Toast.loading(intl.get('WAITING'), 0);

        const {kid, inviteKid} = this.state;

        Promise.all([
            net.getRewardCheckKID({kid:kid}),
            net.getRewardCheckKID({kid:inviteKid}),
        ]).then(res => {
            Toast.hide();
            if(res[0].content === 1)
            {
                Toast.fail(intl.get('TEXT_23'));
            }
            else if(res[1].content === 0)
            {
                Toast.fail(intl.get('TEXT_24'));
            }
            else if(res[0].content === 0 && res[1].content === 1) {
                this.register();
            }
        })
    }

    async register() {

        const {balance} = this.props.redux;
        const {fee, address, kid, inviteKid} = this.state;


        if(Number(balance.kht) <= Number(fee))
        {
            Toast.fail(intl.get('BALANCE_0'));
            return;
        }

        Toast.loading(intl.get('WAITING'), 0);

        const hash = await KHCCampaignNode(address, kid, inviteKid, fee);

        console.log('hash', hash);

        if (hash) await this.checkHash(hash, () => {
            // DeviceEventEmitter.emit('KIDData');
            // this.props.history.goBack();
            Toast.success(intl.get('CHAIN_HANDLE'));
        }, intl.get('TEXT_25'));
    }

    accept(){

        Toast.loading(intl.get('WAITING'), 0);

        const {id, kid} = this.state;

        const params =  signSimulate();
        params.id = id;
        params.kid = kid;

        net.postRewardAcceptInvite(params).then(res => {
            if (res.response_code === '00') {
                Toast.success(intl.get('CHAIN_HANDLE'));
            } else {
                Toast.fail(res.response_msg)
            }
        })
    }

    // 检查hash的结果
    async checkHash(hash, callback, text) {

        const result = await window.KHCExtension.khc.getTransaction(hash);

        console.log("result", result);

        if (result.ret) {
            if(result.ret && result.ret[0]['contractRet'] === 'SUCCESS'){
                callback();
            } else {
                Toast.fail(text);
            }
        }
        else {
            setTimeout(() => this.checkHash(hash, callback, text), 1000)
        }
    }

    renderStep1(){

        const {address, addressError, fee} = this.state;
        const {balance} = this.props.redux;
        const row = this.getRows();


        const disable = !address || address === '' || addressError || (Number(balance.kht) <= Number(fee));

        return (<div>
            <Input
                width={'81.33vw'}
                title={intl.get('TEXT_26') /*交易金额*/}
                value={address}
                error={addressError}
                onChange={(val) => {
                    this.setState({ address:val }, () => {
                        if (!val || !window.KHCExtension.isAddress(val)) {
                            this.setState({ addressError: intl.get('TEXT_27')})
                        }
                        else {
                            this.setState({ addressError: '' });
                        }
                    });
                }}
            />
            <div className={'flex-between'} style={{marginTop:'3vw', marginBottom:'6.4vw'}}>
                <div className={'kid-p1'}>{intl.get('TEXT_28')}</div>
                <div className={'kid-p2'}>{balance.kht} KHC</div>
            </div>
            <div>
                {row.map((item, index)=>{
                    return <div key={index} style={{color:'#525066', fontSize:'3.47vw', lineHeight:'5.07vw'}}>
                        {item}
                    </div>
                })}
            </div>
            <div onClick={disable ? ()=>{}:()=>{
                this.register();
            }} className={disable ? 'kid-btn kid-btn-disable':'kid-btn'} style={{marginTop:'10.8vw'}}>
                {intl.get('TEXT_29')}
            </div>
        </div>)
    }

    renderStep2(){

        const {balance} = this.props.redux;
        const row = this.getRows();

        const {inviteKid, inviteKidError, kid, kidError, fee} = this.state;

        const disable = !kid || kid === '' || kidError || !inviteKid || inviteKid === '' || inviteKidError || (Number(balance.kht) <= Number(fee));

        return (<div>
            <Input
                width={'81.33vw'}
                title={intl.get('TEXT_30') /*交易金额*/}
                value={inviteKid}
                error={inviteKidError}
                onChange={(val) => {
                    this.setState({ inviteKid:val }, () => {
                        if (!/^[A-Za-z0-9]{8}$/.test(val)) {
                            this.setState({ inviteKidError: intl.get('TEXT_31') })
                        } else {
                            this.setState({ inviteKidError: '' });
                        }
                    });
                }}
            />
            <Input
                width={'81.33vw'}
                title={intl.get('TEXT_32') /*交易金额*/}
                value={kid}
                error={kidError}
                onChange={(val) => {
                    this.setState({ kid:val }, () => {
                        if (!/^[A-Za-z0-9]{8}$/.test(val)) {
                            this.setState({ kidError: intl.get('TEXT_31') })
                        } else {
                            this.setState({ kidError: '' });
                        }
                    });
                }}
            />
            <div className={'flex-between'} style={{marginBottom:'6.4vw'}}>
                <div className={'kid-p1'}>{intl.get('TEXT_28')}</div>
                <div className={'kid-p2'}>{balance.kht} KHC</div>
            </div>
            <div>
                {row.map((item, index)=>{
                    return <div key={index} style={{color:'#525066', fontSize:'3.47vw', lineHeight:'5.07vw'}}>
                        {item}
                    </div>
                })}
            </div>
            <div onClick={disable ? ()=>{}:()=>{
                this.check();
            }} className={disable ? 'kid-btn kid-btn-disable':'kid-btn'} style={{marginTop:'10.8vw'}}>
                {intl.get('TEXT_29')}
            </div>
        </div>)
    }

    renderStep3(){

        const {inviteKid, kid, kidError} = this.state;
        const row = this.getRows();

        const disable = !kid || kid === '' || kidError;

        return (<div>
            <div className={'flex-between'} style={{marginBottom:'7vw'}}>
                <div className={'kid-p1'}>{intl.get('TEXT_33')}</div>
                <div className={'kid-p2'}>{inviteKid}</div>
            </div>
            <Input
                width={'81.33vw'}
                title={intl.get('TEXT_32') /*交易金额*/}
                value={kid}
                error={kidError}
                onChange={(val) => {
                    this.setState({ kid:val }, () => {
                        if (!/^[A-Za-z0-9]{8}$/.test(val)) {
                            this.setState({ kidError: intl.get('TEXT_31') })
                        } else {
                            this.setState({ kidError: '' });
                        }
                    });
                }}
            />
            <div>
                {row.map((item, index)=>{
                    return <div key={index} style={{color:'#525066', fontSize:'3.47vw', lineHeight:'5.07vw', width:'87.07'}}>
                        {item}
                    </div>
                })}
            </div>
            <div onClick={disable ? ()=>{}:()=>{
                this.accept();
            }} className={disable ? 'kid-btn kid-btn-disable':'kid-btn'} style={{marginTop:'10.8vw'}}>
                {intl.get('TEXT_29')}
            </div>
        </div>)
    }

    render() {

        const {step} = this.state;


        let renderItem = {};

        switch (step) {
            case 0:
                renderItem = this.renderStep1();
                break;
            case 1:
                renderItem = this.renderStep2();
                break;
            case 2:
                renderItem = this.renderStep3();
                break;
        }

        return (
            <div className={'kid'}>
                <div style={{backgroundColor:'white', padding:'5.33vw'}}>
                    {renderItem}
                </div>
            </div>
        );
    }
}

export default connect(InviteKid);
