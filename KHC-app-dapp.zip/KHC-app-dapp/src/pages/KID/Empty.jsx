import React, { Component } from "react";

export default class Empty extends Component {

    constructor(props){
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        // this.login();
        // this.getNotice();
    }

    componentWillUnmount() {

    }

    render() {
        return (
            <div style={{width:'100vw', height:'100vh', backgroundColor:'white'}} className={'flex-center-col'}>
                <img alt='' src={require('../../images/kid/update.png')} style={{width:'60vw', height:'51.2vw'}} />
                <div style={{fontSize:'4.27vw', color:"#878B93", marginTop:'8vw'}}>努力升级中…</div>
            </div>
        );
    }
}
