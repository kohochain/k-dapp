import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import intl from "react-intl-universal";
import net from "../../server";
import connect from "../../store/connect";
import moment from "moment";
import {signTimestamp} from "../../utils/mdc";
import setLanguage from "../setLanguage";
import copy from "copy-to-clipboard";
import Web from "./Web";

const Item = Popover.Item;

const imgs = {
    'bg':require('../../images/kid/reward-bg.png'),
    'down':require('../../images/kid/arrow-down.png'),
    'copy':require('../../images/copy.png'),
};


class Reward extends Component {

    constructor(props){
        super(props);
        this.state = {
            visible:false,
            lang: localStorage.getItem('lang'),
            airdrop:-1,
        }
    }

    componentDidMount() {
        // this.login();
        // this.getNotice();
        Toast.loading(intl.get('WAITING'), 0);
        this.setDevice();
        this.check();
    }

    setDevice() {

        const that = this;

        window.addEventListener("message", function handler(e) {
            // console.log('message', e);
            if (e && e.data) {
                let obj = JSON.parse(e.data);
                if(obj.method === 'venaPi.deviceId')
                {
                    console.log(obj.deviceId);
                    that.setState({deviceId:obj.deviceId});
                    window.removeEventListener('message', () => {
                    })
                }
            }
        });

        document.addEventListener("message", function handler(e) {
            // console.log('message', e);
            if (e && e.data) {
                let obj = JSON.parse(e.data);
                if(obj.method === 'venaPi.deviceId')
                {
                    console.log(obj.deviceId);
                    that.setState({deviceId:obj.deviceId});
                    document.removeEventListener('message', () => {
                    })
                }
            }
        })
    }

    check(){

        const {address} = this.props.redux;

        if (address) {

            Toast.hide();
            localStorage.setItem('address', address);
            net.getKHTRewardAirdrop({address:address}).then(res => {
                if (res.response_code === '00') {
                    if(res.content !== null){
                        this.setState({airdrop:res.content});
                    }
                }
            }).catch(

            );


        } else {
            setTimeout(() => this.check(), 3000)
        }
    }

    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {

            localStorage.setItem('address', address);
            Toast.hide();


        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    async getReward() {

        const {usdt, vds, pro} = this.props.redux.balance;

        if(usdt < 10 && vds < 10 && pro < 0.1) {
            Toast.fail(intl.get('TEXT_34'));
            return ;
        }

        Toast.loading(intl.get('WAITING'), 0);

        const params = await signTimestamp();

        net.getKHTRewardFee(params).then(res => {
            if (res.response_code === '00') {
                Toast.hide();
                this.setState({visible:true});
            } else {
                if(res.response_code === '100016'){
                    Toast.fail(intl.get('TEXT_61'));
                }
                if(res.response_code === '100017'){
                    Toast.fail(intl.get('TEXT_62'));
                }
                if(res.response_code === '100018'){
                    Toast.fail(intl.get('TEXT_63'));
                }
                else {
                    Toast.fail(res.response_msg);
                }
            }
        }).catch(

        );
    }

    async getPro() {

        // const {usdt, vds, pro} = this.props.redux.balance;
        //
        // if(usdt < 10 && vds < 10 && pro < 0.1) {
        //     Toast.fail(intl.get('TEXT_34'));
        //     return ;
        // }

        Toast.loading(intl.get('WAITING'), 0);

        const params = await signTimestamp();
        params.deviceId = this.state.deviceId; //this.state.deviceId

        net.getKHTProAirdrop(params).then(res => {
            if (res.response_code === '00') {
                Toast.success(intl.get('TEXT_35'));
                this.setState({airdrop:-1});
            } else {
                if(res.response_code === '10020'){
                    Toast.fail(intl.get('TEXT_48'));
                }
                if(res.response_code === '10021'){
                    Toast.fail(intl.get('TEXT_49'));
                }
                if(res.response_code === '10022'){
                    Toast.fail(intl.get('TEXT_50'));
                }
                else {
                    Toast.fail(res.response_msg);
                }
            }
        }).catch(

        );
    }

    changeLanguage(lang) {
        setLanguage(lang).then(() => {
            this.setState({ lang })
            localStorage.setItem('lang', lang);
        })
    }

    renderH5() {

        const {visible, lang, airdrop} = this.state;

        let language;
        switch (lang) {
            case 'zh':
                language = '简体中文';
                break;
            case 'en':
                language = 'English';
                break;
            case 'jp':
                language = '日本語';
                break;
            case 'ko':
                language = '한국어';
                break;
            default:
                language = '简体中文';
                break;
        }

        return (
            <div className={'kid-reward'}>
                <Modal
                    popup
                    visible={visible}
                    onClose={()=>{this.setState({visible:false})}}
                    // animationType="slide-up"
                    // afterClose={() => { onClose() }}
                >
                    <div className={'flex-center-col'} style={{width:"100vw", height:"100vh"}}>
                        <div className={'flex-center-col toast'}>
                            <div style={{width:'100%'}} className={'toast-text'}>{intl.get('TEXT_35')}</div>
                            <div style={{width:'100%'}} className={'toast-text'}>{intl.get('TEXT_38')}</div>
                            <div onClick={()=>{window.location = "https://kex.khchain.io/"}} className={'toast-btn'}>
                                {intl.get('TEXT_39')}
                            </div>
                        </div>
                    </div>
                </Modal>
                <img alt='' src={imgs['bg']} className={'kid-reward-bg'} />
                <Popover mask
                         overlayClassName="fortest"
                         overlayStyle={{ color: 'currentColor' }}
                         visible={this.state.visible2}
                         overlay={[
                             (<Item key="1" value={'zh'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>简体中文</p>
                                 </div>
                             </Item>),
                             (<Item key="2" value={'en'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>English</p>
                                 </div>
                             </Item>),
                             (<Item key="3" value={'ko'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>한국어</p>
                                 </div>
                             </Item>),
                             (<Item key="4" value={'jp'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>日本語</p>
                                 </div>
                             </Item>),
                         ]}
                         align={{
                             overflow: { adjustY: 0, adjustX: 0 },
                             offset: [-10, 0],
                         }}
                    // onVisibleChange={()=>{this.setState({visible2:false})}}
                         onSelect={(opt)=>{
                             this.setState({
                                 visible2: false,
                             }, ()=>{
                                 this.changeLanguage(opt.props.value);
                             });
                         }}
                >
                    <div onClick={()=>{this.setState({visible2:true})}} className={'kid-reward-language'}>
                        <div className={'flex-between'} style={{padding:'1.33vw 3.2vw'}}>
                            <div className={'kid-reward-language-title'}>{language}</div>
                            <img className={'kid-reward-language-arrow'} alt='' src={imgs['down']} />
                        </div>
                    </div>
                </Popover>
                <div className={'kid-reward-card'}>
                    <div className={'p-4'}>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_36')}
                        </div>
                        <div onClick={()=>{this.getReward()}} className={'kid-reward-btn'}>{intl.get('TEXT_37')}</div>
                    </div>
                </div>
                <div className={'kid-reward-card'} style={{marginTop:'5.33vw', marginBottom:'5.33vw'}}>
                    <div className={'p-4'}>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_40')}
                        </div>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_41')}
                        </div>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_42')}
                        </div>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_43')}
                        </div>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_44')}
                        </div>
                        <div className={'kid-reward-p'}>
                            {intl.get('TEXT_45')}
                        </div>
                        <div className={'flex-display'}>
                            <div className={'kid-reward-p'}>
                                {intl.get('TEXT_46')}
                            </div>
                            <img
                                onClick={()=>{
                                    copy(intl.get('TEXT_46') || '-');
                                    Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                                }}
                                src={imgs.copy} alt='' style={{width:'4vw', height:'4vw', marginLeft:'2vw'}} />
                        </div>
                        <div onClick={
                            airdrop === -1 ? ()=>{}: ()=>{this.getPro()}}
                             style={{opacity:airdrop === -1 ? 0.6:1}}
                             className={'kid-reward-btn'}>{airdrop === -1 ? intl.get('TEXT_60'):intl.get('TEXT_37')}</div>
                    </div>
                </div>
            </div>
        );
    }

    render() {
        if(Storage.mobile)
        {
            return this.renderH5();
        }

        return <Web />
    }
}

export default connect(Reward);
