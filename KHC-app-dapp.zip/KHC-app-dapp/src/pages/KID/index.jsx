import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import intl from "react-intl-universal";
import net from "../../server";
import connect from "../../store/connect";
import moment from "moment";
import isNullObject from "../../utils/isNull";
import {getWithdrawFee, signSimulate} from "../../utils/mdc";
import copy from "copy-to-clipboard";
import setLanguage from "../setLanguage";

const Item = Popover.Item;

const imgs = {
    'avatar':require('../../images/kid/avatar.png'),
    'copy':require('../../images/kid/copy.png'),
    'empty':require('../../images/kid/empty.png'),
    'down':require('../../images/kid/kid-arrow-down.png'),
};

class Index extends Component {

    constructor(props){
        super(props);
        this.state = {
            list:[],
            inviteList:[],
            step:1,
            kid:'',
            lang: localStorage.getItem('lang'),
        }
    }

    componentDidMount() {
        this.login();
        // this.getNotice();
    }


    async login() {
        const {address} = this.props.redux;

        Toast.loading(intl.get('WAITING'), 0);

        if (address) {

            localStorage.setItem('address', address);

            this.checkKid();

        } else {
            setTimeout(() => this.login(), 3000)
        }
    }

    checkKid(){

        const params = signSimulate();

        net.postRewardAddressInfo(params).then(res => {
            Toast.hide();
            if(res.response_code === '00')
            {
                this.setState(res.content)
                this.setState({step:2});
                this.getMyInviteList();
            }
            else {
                this.setState({step:1});
                this.getInviteList();
            }
        });
    }

    getInviteList(){

        const params = signSimulate();

        net.inviteRewardPipeline(params).then(res => {
            if(res.response_code === '00')
            {
                this.setState({list:res.content});
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    getMyInviteList(){

        const params = signSimulate();
        params.pageSize = 50;

        net.postRewardInviteList(params).then(res => {
            if(res.response_code === '00')
            {
                this.setState({inviteList:res.content.infoList});
            }
            else {
                Toast.fail(res.response_msg);
            }
        });
    }

    componentWillUnmount() {
        if (this.timer) {
            clearTimeout(this.timer) && (this.timer = null)
        }
    }

    changeLanguage(lang) {
        setLanguage(lang).then(() => {
            this.setState({ lang })
            localStorage.setItem('lang', lang);
        })
    }

    renderList(){

        const {list} = this.state;

        return (
            <div className={'flex-display-col'} style={{marginTop:'-8.33vw', marginBottom:'5.33vw'}}>
                {list.map((item, index)=>{
                    return <div className={'kid-list-cell flex-between'} key={index}>
                        <div className={'kid-list-cell-p'}>
                            {intl.get('TEXT_1', {inviteKid:item.inviteKid})}
                        </div>
                        <div className={'kid-list-cell-btn flex-center'}>
                            <div onClick={()=>{this.props.history.push({pathname:"/invite", query:{step:2, kid:item.inviteKid, id:item.id}})}} className={'kid-list-cell-text'}>
                                {intl.get('TEXT_2')}
                            </div>
                        </div>
                    </div>
                })}
            </div>
        )
    }

    renderStep2(){

        const {inviteList, kid} = this.state;

        return (<div className={'flex-display-col'}>
            <div className={'kid-card relative'}>
                <div className={'flex-display'} style={{marginTop:'8.8vw', marginLeft:'8.8vw'}}>
                    <img style={{width:'14.67vw', height:"14.67vw"}} alt='' src={imgs['avatar']} />
                    <div style={{marginLeft:'5.33vw'}}>
                        <div style={{color:'white', fontSize:'5.33vw', fontWeight:'bold', marginBottom:'4vw'}}>
                            {intl.get('TEXT_3')}
                        </div>
                        <div className={'flex-display'}>
                            <div style={{color:'#A9A6C0', fontSize:'3.73vw'}}>
                                KID：{kid}
                            </div>
                            <img onClick={()=>{
                                copy(kid || '-');
                                Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                            }} src={imgs['copy']} alt='' style={{width:'3.2vw', height:'3.2vw', marginLeft:'2.53vw'}} />
                        </div>
                    </div>
                </div>
                <div onClick={()=>{this.props.history.push({pathname:"/invite", query:{step:0}})}} className={'kid-card-invite'}>
                    {intl.get('TEXT_4')}
                </div>
            </div>
            {inviteList.length ? <div>
                <div style={{color:'#525066', fontSize:'4.53vw'}}>{intl.get('TEXT_5')}</div>
                <div>
                    {inviteList.map((item, index)=> {
                        return <div key={index} className={'kid-card-cell'}>
                            <div style={{backgroundColor:'#D5DAF5', width:'100%'}}>
                                <div className={'flex-between'} style={{padding:'4vw'}}>
                                    <div className={'kid-card-cell-p1'}>{intl.get('TEXT_6')}</div>
                                    <div className={'kid-card-cell-p1'}>KID:{item.kid}</div>
                                </div>
                            </div>
                            <div className={'p-4'}>
                                <div className={'flex-between'}>
                                    <div className={'kid-card-cell-p2'}>{intl.get('TEXT_7')}</div>
                                    <div className={'kid-card-cell-p1'}>{moment(item.createTime).format('YYYY.MM.DD HH:mm:ss')}</div>
                                </div>
                                <div className={'flex-between'} style={{marginTop:'4vw'}}>
                                    <div className={'kid-card-cell-p2'}>{intl.get('TEXT_8')}</div>
                                    <div className={'kid-card-cell-p1'}>{item.inviteCount}</div>
                                </div>
                            </div>
                        </div>
                    })}
                </div>
            </div> : <div className={'flex-center-col'}>
                <img style={{width:'33.33vw', height:'26.93vw', marginTop:"30vw"}} alt='' src={imgs['empty']} />
                <div style={{color:'#AAA8C0', fontSize:'3.73vw', marginTop:'5.33vw'}}>{intl.get('TEXT_9')}</div>
            </div>}
        </div>)
    }

    render() {

        const {list, step, lang} = this.state;

        let language;
        switch (lang) {
            case 'zh':
                language = '简体中文';
                break;
            case 'en':
                language = 'English';
                break;
            case 'jp':
                language = '日本語';
                break;
            case 'ko':
                language = '한국어';
                break;
            default:
                language = '简体中文';
                break;
        }

        return (
            <div className={'kid'}>
                <Popover mask
                         overlayClassName="fortest"
                         overlayStyle={{ color: 'currentColor' }}
                         visible={this.state.visible2}
                         overlay={[
                             (<Item key="1" value={'zh'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>简体中文</p>
                                 </div>
                             </Item>),
                             (<Item key="2" value={'en'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>English</p>
                                 </div>
                             </Item>),
                             (<Item key="3" value={'ko'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>한국어</p>
                                 </div>
                             </Item>),
                             (<Item key="4" value={'jp'}>
                                 <div className={'btn-sub flex-center'}>
                                     <p className={'btn-text2'}>日本語</p>
                                 </div>
                             </Item>),
                         ]}
                         align={{
                             overflow: { adjustY: 0, adjustX: 0 },
                             offset: [-10, 0],
                         }}
                    // onVisibleChange={()=>{this.setState({visible2:false})}}
                         onSelect={(opt)=>{
                             this.setState({
                                 visible2: false,
                             }, ()=>{
                                 this.changeLanguage(opt.props.value);
                             });
                         }}
                >
                    <div className={'flex-end'}>
                        <div onClick={()=>{this.setState({visible2:true})}} className={'kid-language'}>
                            <div className={'flex-between'} style={{padding:'1vw 2.67vw'}}>
                                <div className={'kid-language-text'}>{language}</div>
                                <img className={'kid-language-arrow'} alt='' src={imgs['down']} />
                            </div>
                        </div>
                    </div>
                </Popover>
                {step === 1 ? <div>
                    <div className={'kid-bg flex-display-col'}>
                        <div className={'kid-bg-title'}>
                            {intl.get('TEXT_10')}
                        </div>
                        <div onClick={()=>{this.props.history.push({pathname:"/invite", query:{step:1}})}} className={'kid-bg-btn'}>{intl.get('TEXT_11')}</div>
                    </div>
                    {list.length ? this.renderList():null}
                </div> : this.renderStep2()}
            </div>
        );
    }
}

export default connect(Index);
