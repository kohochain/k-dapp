import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import connect from "../store/connect";
import setLanguage from "./setLanguage";
import intl from "react-intl-universal";
import WebHome from "./WebHome";

const Item = Popover.Item;

const imgs = {
    'down':require('../images/kid/kid-arrow-down.png'),
    'banner':require('../images/home/banner.png'),
    'kdex':require('../images/home/kdex.png'),
    'ktmining':require('../images/home/ktmining.png'),
    'bridge':require('../images/home/bridge.png'),
    'swap':require('../images/home/ProSwap.png'),
    'gas':require('../images/home/gas.png'),
    'kid':require('../images/home/kid.png'),
};

class Home extends Component {

    constructor(props){
        super(props);
        this.state = {
            lang: localStorage.getItem('lang'),
        }
    }

    componentDidMount() {

    }

    componentWillUnmount() {

    }

    changeLanguage(lang) {
        setLanguage(lang).then(() => {
            this.setState({ lang })
            localStorage.setItem('lang', lang);
        })
    }

    renderCell(item, index){

        return (
            <div key={index} className={'home-card-cell'}>
                <div className={'flex-between'} style={{padding:'0 4vw', height:'100%'}}>
                    <div className={'flex-display'}>
                        <img src={item.img} alt='' className={'home-card-cell-icon'} />
                        <div>
                            <div className={'home-card-cell-p1'}>{item.title}</div>
                            <div className={'home-card-cell-p2'}>{item.text}</div>
                        </div>
                    </div>
                    <div onClick={()=>{window.location = item.url}} className={'home-card-cell-btn flex-center'}>
                        <div className={'home-card-cell-p3'}>GET</div>
                    </div>
                </div>
                <div className={'home-card-cell-line'}/>
            </div>
        )
    }

    renderH5() {

        const {list, step, lang} = this.state;

        let language;
        switch (lang) {
            case 'zh':
                language = '简体中文';
                break;
            case 'en':
                language = 'English';
                break;
            case 'jp':
                language = '日本語';
                break;
            case 'ko':
                language = '한국어';
                break;
            default:
                language = '简体中文';
                break;
        }

        const array = [
            {title:'ProSwap', img:imgs['swap'], text:intl.get('TEXT_54'), url:'https://proswap.khchain.io/'},
            {title:'KoHo Bridge', img:imgs['bridge'], text:intl.get('TEXT_51'), url:'https://bridge.khchain.io/'},
            {title:'Gas Station', img:imgs['gas'], text:intl.get('TEXT_52'), url:'https://kid.khchain.io/#/reward'},
            {title:'KDex', img:imgs['kdex'], text:intl.get('TEXT_53'), url:'https://kex.khchain.io/'},
            {title:'KT Mining', img:imgs['ktmining'], text:intl.get('TEXT_55'), url:'https://kt.khchain.io/#/'},
            {title:'KID', img:imgs['kid'], text:intl.get('TEXT_56'), url:'https://kid.khchain.io/#/'},
        ];

        return (
            <div className={'home'}>
                <div className={'p-4'}>
                    <div className={'flex-between'}>
                        <div className={'flex-display'}>
                            <div className={'home-tag'}/>
                            <div className={'home-title'}>{intl.get('TEXT_57')}</div>
                        </div>
                        <Popover mask
                                 overlayClassName="fortest"
                                 overlayStyle={{ color: 'currentColor' }}
                                 visible={this.state.visible2}
                                 overlay={[
                                     (<Item key="1" value={'zh'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>简体中文</p>
                                         </div>
                                     </Item>),
                                     (<Item key="2" value={'en'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>English</p>
                                         </div>
                                     </Item>),
                                     (<Item key="3" value={'ko'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>한국어</p>
                                         </div>
                                     </Item>),
                                     (<Item key="4" value={'jp'}>
                                         <div className={'btn-sub flex-center'}>
                                             <p className={'btn-text2'}>日本語</p>
                                         </div>
                                     </Item>),
                                 ]}
                                 align={{
                                     overflow: { adjustY: 0, adjustX: 0 },
                                     offset: [-10, 0],
                                 }}
                            // onVisibleChange={()=>{this.setState({visible2:false})}}
                                 onSelect={(opt)=>{
                                     this.setState({
                                         visible2: false,
                                     }, ()=>{
                                         this.changeLanguage(opt.props.value);
                                     });
                                 }}
                        >
                            <div className={'flex-end'}>
                                <div onClick={()=>{this.setState({visible2:true})}} className={'kid-language'} style={{margin:0}}>
                                    <div className={'flex-between'} style={{padding:'1vw 2.67vw'}}>
                                        <div className={'kid-language-text'}>{language}</div>
                                        <img className={'kid-language-arrow'} alt='' src={imgs['down']} />
                                    </div>
                                </div>
                            </div>
                        </Popover>
                    </div>
                    <div onClick={()=>{window.location = 'https://proswap.khchain.io/'}} className={'home-card'}>
                        <img alt='' src={imgs['banner']} className={'home-card-banner'} />
                        <div className={'p-4'}>
                            <div className={'home-card-text'}>
                                {intl.get('TEXT_58')}
                            </div>
                        </div>
                    </div>
                    <div className={'flex-display'}>
                        <div className={'home-tag'}/>
                        <div className={'home-title'}>{intl.get('TEXT_59')}</div>
                    </div>
                    <div className={'home-card'}>
                        {array.map((item, index)=> {
                            return this.renderCell(item, index);
                        })}
                    </div>
                </div>
            </div>
        );
    }

    render(){
        if(Storage.mobile)
        {
            return this.renderH5();
        }

        return <WebHome />

    }
}

export default connect(Home);
