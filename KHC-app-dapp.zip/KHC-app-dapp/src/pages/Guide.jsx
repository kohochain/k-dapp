import React, { Component } from "react";
import {Modal, Toast, Switch, Carousel, Popover} from 'antd-mobile';
import connect from "../store/connect";
import setLanguage from "./setLanguage";
import intl from "react-intl-universal";
import copy from "copy-to-clipboard";

const imgs = {
    'copy':require('../images/home/copy.png')
};

class Guide extends Component {

    constructor(props){
        super(props);
        this.state = {
            lang: 'zh',
        }
    }

    componentDidMount() {

    }

    componentWillUnmount() {

    }

    renderEn(){
        return (
            <div className={'guide-en relative'}>
                <div className={'flex-end'}>
                    <div onClick={()=>{this.setState({lang:'zh'})}} className={'kid-language'} style={{margin:'5.33vw', borderColor:'white', borderRadius:'3.2vw'}}>
                        <div className={'flex-center'} style={{padding:'1vw 2.67vw'}}>
                            <div className={'kid-language-text'} style={{color:'white'}}>中文版</div>
                        </div>
                    </div>
                </div>
                <div className={'flex-display'} style={{position:'absolute', top:'96vw', left:'10.93vw'}}>
                    <div className={'guide-p'}>https://t.me/ProSwapCommunityCenter</div>
                    <img onClick={()=>{
                        copy('https://t.me/ProSwapCommunityCenter');
                        Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                    }} src={imgs['copy']} alt='' className={'guide-copy'} />
                </div>
                <div className={'flex-display'} style={{position:'absolute', top:'109.6vw', left:'10.93vw'}}>
                    <div className={'guide-p'}>https://t.me/KoHoChain</div>
                    <img onClick={()=>{
                        copy('https://t.me/KoHoChain');
                        Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                    }} src={imgs['copy']} alt='' className={'guide-copy'} />
                </div>
                <div className={'flex-display'} style={{position:'absolute', top:'122.93vw', left:'10.93vw'}}>
                    <div className={'guide-p'}>https://twitter.com/ChainKoho</div>
                    <img onClick={()=>{
                        copy('https://twitter.com/ChainKoho');
                        Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                    }} src={imgs['copy']} alt='' className={'guide-copy'} />
                </div>
            </div>
        )
    }

    renderZh(){
        return (
            <div className={'guide-zh relative'}>
                <div className={'flex-end'}>
                    <div onClick={()=>{this.setState({visible2:true})}} className={'kid-language'} style={{margin:'5.33vw', borderColor:'white', borderRadius:'3.2vw'}}>
                        <div onClick={()=>{this.setState({lang:'en'})}} className={'flex-center'} style={{padding:'1vw 2.67vw'}}>
                            <div className={'kid-language-text'} style={{color:'white'}}>English</div>
                        </div>
                    </div>
                </div>
                <div className={'flex-display'} style={{position:'absolute', top:'117.33vw', left:'10.93vw'}}>
                    <div className={'guide-p'}>或者下载链接：https://www.btok.io/</div>
                    <img onClick={()=>{
                        copy('https://www.btok.io/');
                        Toast.success(intl.get('COPY_SUCCESS'), 2, () => {}, false)
                    }} src={imgs['copy']} alt='' className={'guide-copy'} />
                </div>
            </div>
        )
    }

    render() {

        return (
            <div style={{overflow:'scroll', height:'100vh'}}>
                {this.state.lang === 'en' ? this.renderEn():this.renderZh()}
            </div>
        );
    }
}

export default connect(Guide);
