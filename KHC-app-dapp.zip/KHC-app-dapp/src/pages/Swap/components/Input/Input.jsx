import React, { Component } from "react";

class Input extends Component {

    constructor(props){
        super(props);
        this.state = {
            tab:0,
        }
    }

    setBlur(){

        const {onBlur} = this.props;

        if(onBlur){
            onBlur();
        }

        this.setState({focus:false});
    }

    setFocus(){
        this.setState({focus:true});
    }


    render() {
        const { value, onChange, title, tag, disabled, width, error, placeholder, subTitle, onBlur, green, balance, onMax} = this.props;

        const {focus} = this.state;

        return (
            <div>
                <div className={'common-input-label'}>{title}</div>
                <div className="common-input">
                    {tag ? <div onClick={onMax ? ()=>{onMax()} : ()=>{}} className={'common-input-tag'}>{tag}</div> : null}
                    <input
                        style={error ? {borderColor:'#E62D2D', width:width}:(focus ? {borderColor:'#627EEA', width:width}:{borderColor:'#E0E0E0', width:width})}
                        onChange={(value) => {onChange(value.target.value)}}
                        value={value}
                        onFocus={()=>{this.setFocus()}}
                        onBlur={()=>{this.setBlur()}}
                        placeholder={placeholder || ''}
                        type={'text'}
                        disabled={disabled}
                    />
                    {
                        error ?
                            <div className={'common-input-err'}>{error}</div>
                            :
                            <div style={{height: '5vw'}} />
                    }
                    {
                        balance ? <div className={'common-input-label'} style={{textAlign:"right"}}>{balance}</div>
                            :
                            null
                    }
                </div>
            </div>
        );
    }
}

export default Input;
