import React, { PureComponent } from "react";

class Header extends PureComponent {

    render() {
        const { marginTop, no } = this.props;
        return (
            <React.Fragment>
                <div className="no-record flex-center-col" style={{marginTop: marginTop ? marginTop : '30vw' }}>
                    <img src={require('../images/no-record.png')}/>
                    {no ? null : <div className={'no-record-text m-t-3'}>暂无记录</div>}
                </div>
            </React.Fragment>
        );
    }
}

export default Header;
