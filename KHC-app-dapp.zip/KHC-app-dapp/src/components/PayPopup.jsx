import React, { Component } from "react";
import { Modal } from 'antd-mobile';

class PayPopup extends Component {

    render() {
        const { 
                visible,
                onClose,
                onChange,
                onConfirm
            } = this.props;

        return (
            <Modal
                visible={visible}
                onClose={onClose}
                popup
                animationType="slide-up"
            >
                <div className={'pop'}>
                    <div className={'flex-start p-l-5 p-r-5'}>
                        <div className={'pop-cancel'} onClick={onClose}>取消</div>
                        <div className={'pop-title text-center'}>安全验证</div>
                    </div>
                    <div className={'pop-line m-t-4'}></div>
                    <div className={'p-l-5 p-r-5'}>
                        <div className={'pop-title text-left m-t-8 m-b-3'}>钱包密码</div>
                        <input
                            className={'pop-input'}
                            placeholder="请输入钱包密码"
                            type="password"
                            onChange={(value) => onChange(value.target.value)} 
                        />
                        <div className={'pop-btn m-t-8'} onClick={onConfirm}>确认</div>
                    </div>
                </div>
            </Modal>
        );
    }
}

export default PayPopup;
