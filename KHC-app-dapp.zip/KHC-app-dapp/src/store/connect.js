import { connect } from 'react-redux';
import * as actions from './actions';
import {getUSDTBalance, getBalance, getProBalance, getVDSBalance} from "../utils/mdc";
import net from "../server";

const mapStateToProps = state => ({
    redux: state.redux,
});

const mapDispatchToProps = dispatch => ({
    setAddress: (address) => {
        dispatch(actions.setAddress(address))
    },
    updateBalance: async () => {
        let data = { eth: 0, usdt: 0, fee: 0.0001 };
        // data.usdt = await get20BalanceResult();
        data.kht = await getBalance();
        data.usdt = await getUSDTBalance();
        data.vds = await getVDSBalance();
        data.pro = await getProBalance();

        console.log("data", data);

        // data.fee = await getFee();

        data.fee = Number(data.fee || 0.0001);
        dispatch(actions.updateBalance(data))
    },
    setDevice: (deviceId) => {
        dispatch(actions.setDevice(deviceId))
    },
    setBalance:(data) => { dispatch(actions.setBalance(data)) },

    updatePtBalance: async (address) => {

        let result = await net.getMyBalance({address:address});

        if(result.response_code === '00')
        {
            const data = result.content;

            dispatch(actions.setPtBalance(data))
        }
    },

    setAccount:(data) => { dispatch(actions.setAccount(data)) },
    setFee: (data) => { console.log('set fee data ------>',data);dispatch(actions.setFee(data)) },
    setActive: (data) => { dispatch(actions.setActive(data)) },
    setTokenList: (data) => { dispatch(actions.setTokenList(data)) },
    setTab: (data) => {
        dispatch(actions.setTab(data));
    },
});

export default c => connect(mapStateToProps, mapDispatchToProps)(c);
